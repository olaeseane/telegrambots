const helpMessage = `
Welcome to Search Bot!
Use the inline mode below
@SearchesBot p <search image>
@SearchesBot w <search wiki>
`;

module.exports = {
  helpMessage,
};
